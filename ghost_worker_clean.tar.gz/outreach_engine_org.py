import sqlite3
import os
import json
import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from logging.handlers import RotatingFileHandler
from datetime import datetime, timedelta
from dotenv import load_dotenv

load_dotenv()

LOG_DIR  = os.path.join(os.path.dirname(__file__), 'logs')
DB_PATH  = os.path.join(os.path.dirname(__file__), 'agency.db')
os.makedirs(LOG_DIR, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] [%(levelname)s] [outreach] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    handlers=[
        RotatingFileHandler(
            os.path.join(LOG_DIR, 'ghost_worker.log'),
            maxBytes=5 * 1024 * 1024,
            backupCount=3
        ),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

SMTP_HOST   = os.getenv('SMTP_HOST',     'smtp.hostinger.com')
SMTP_PORT   = int(os.getenv('SMTP_PORT', 465))
SMTP_EMAIL  = os.getenv('SMTP_EMAIL',    '')
SMTP_PASS   = os.getenv('SMTP_PASSWORD', '')
AGENCY_NAME = os.getenv('AGENCY_NAME',   'LaunchPad Web')

# Timing constants
HOURS_FOLLOWUP1   = 48
HOURS_FOLLOWUP2   = 48
DAYS_FINAL        = 30
DAYS_DELETE       = 5
MINUTES_HOT       = 180   # 3 hours window for HOT strike (not 3 min — gives you time to send manually)


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.row_factory = sqlite3.Row
    return conn


def now_str():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def hours_since(dt_str):
    if not dt_str:
        return 999999
    try:
        dt = datetime.strptime(dt_str[:19], '%Y-%m-%d %H:%M:%S')
        return (datetime.now() - dt).total_seconds() / 3600
    except:
        return 999999


def days_since(dt_str):
    return hours_since(dt_str) / 24


def send_email(to_email, subject, body):
    if not to_email or not SMTP_PASS or not SMTP_EMAIL:
        return False
    try:
        msg            = MIMEMultipart('alternative')
        msg['From']    = f'{AGENCY_NAME} <{SMTP_EMAIL}>'
        msg['To']      = to_email
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'plain', 'utf-8'))
        html = f"""<html><body style="font-family:Arial,sans-serif;
            max-width:600px;margin:0 auto;padding:20px;color:#333">
            <p>{body.replace(chr(10),'<br>')}</p>
            <hr style="border:none;border-top:1px solid #eee;margin:20px 0">
            <p style="font-size:12px;color:#999">
            {AGENCY_NAME} · {SMTP_EMAIL}</p>
            </body></html>"""
        msg.attach(MIMEText(html, 'html', 'utf-8'))
        with smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT) as s:
            s.login(SMTP_EMAIL, SMTP_PASS)
            s.sendmail(SMTP_EMAIL, to_email, msg.as_string())
        logger.info(f'  Email sent → {to_email} | {subject[:50]}')
        return True
    except Exception as e:
        logger.error(f'  Email failed → {to_email}: {e}')
        return False

def send_whatsapp_msg(phone, message, tracker_url):
    """Send WhatsApp via Evolution API."""
    if not phone or not message:
        return False
    try:
        from whatsapp_sender import send_whatsapp, check_connection
        if not check_connection():
            logger.warning("WhatsApp not connected — skipping WA send")
            return False
        return send_whatsapp(phone, message, tracker_url)
    except Exception as e:
        logger.error(f"WA send error: {e}")
        return False


def advance_stage(conn, lead_id, new_stage, extra=None):
    params = {
        'stage': new_stage,
        'now':   now_str(),
        'id':    lead_id,
    }
    if extra:
        params.update(extra)

    sets = ['outreach_stage=:stage', 'stage_updated_at=:now']
    if 'last_contacted' in (extra or {}):
        sets.append('last_contacted=:last_contacted')
    if 'followup_count' in (extra or {}):
        sets.append('followup_count=:followup_count')
    if 'lifecycle_status' in (extra or {}):
        sets.append('lifecycle_status=:lifecycle_status')
    if 'scheduled_delete_at' in (extra or {}):
        sets.append('scheduled_delete_at=:scheduled_delete_at')

    conn.execute(
        f"UPDATE leads SET {', '.join(sets)} WHERE id=:id",
        params
    )
    conn.commit()


# ── STAGE PROCESSORS ─────────────────────────────────────

def stage_0_initial(conn, lead):
    """
    Stage 0 → 1
    New deployed lead. Write messages if missing, then mark ready.
    WA cold draft is shown on dashboard for manual send.
    Email sent automatically if email exists.
    """
    lead_id = lead['id']
    name    = lead['business_name']

    # Write messages if not done yet
    if not lead['wa_draft_1']:
        logger.info(f'  Writing messages for ID:{lead_id}')
        try:
            from outreach_writer import write_all_messages
            write_all_messages(dict(lead))
            # Reload fresh
            lead = dict(conn.execute(
                'SELECT * FROM leads WHERE id=?', (lead_id,)
            ).fetchone())
        except Exception as e:
            logger.error(f'  Writer failed: {e}')
            return

    # Send email if available
    if lead.get('email') and lead.get('email_draft_1'):
        try:
            em = json.loads(lead['email_draft_1'])
            send_email(lead['email'], em['subject'], em['body'])
        except Exception as e:
            logger.error(f'  Cold email parse error: {e}')

    advance_stage(conn, lead_id, 1, {
        'last_contacted': now_str(),
        'followup_count': 1,
    })
    logger.info(
        f'  Stage 0→1: {name[:35]} | '
        f'Cold WA draft ready on dashboard'
    )


def stage_hot_strike(conn, lead):
    """
    Special: lead clicked tracker URL (HOT) while at Stage 1.
    Window: within MINUTES_HOT of the click.
    Advances to Stage 2. HOT WA draft shown on dashboard.
    """
    lead_id      = lead['id']
    last_clicked = lead['last_clicked']
    if not last_clicked:
        return False

    mins_since = hours_since(last_clicked) * 60
    if mins_since > MINUTES_HOT:
        return False

    name = lead['business_name']
    logger.info(
        f'  HOT STRIKE: {name[:35]} | '
        f'Clicked {mins_since:.0f}min ago'
    )

    # Send hot email if available
    if lead.get('email') and lead.get('email_draft_hot'):
        try:
            em = json.loads(lead['email_draft_hot'])
            send_email(lead['email'], em['subject'], em['body'])
        except Exception as e:
            logger.error(f'  HOT email error: {e}')

    advance_stage(conn, lead_id, 2, {
        'followup_count': (lead['followup_count'] or 0) + 1,
        'last_contacted': now_str(),
    })
    logger.info(f'  Stage 1→2 (HOT STRIKE) | WA hot draft ready on dashboard')
    return True


def stage_followup1(conn, lead):
    """
    Stage 1/2 → 3
    48h after last contact, no reply. Send followup 1.
    """
    lead_id = lead['id']
    ref     = lead['last_contacted'] or lead['created_at']
    hrs     = hours_since(ref)

    if hrs < HOURS_FOLLOWUP1:
        logger.debug(
            f'  F1 not ready: {lead["business_name"][:30]} '
            f'({hrs:.0f}h / need {HOURS_FOLLOWUP1}h)'
        )
        return

    name = lead['business_name']
    logger.info(f'  Followup 1: {name[:35]} ({hrs:.0f}h since contact)')

    if lead.get('email') and lead.get('email_draft_2'):
        try:
            em = json.loads(lead['email_draft_2'])
            send_email(lead['email'], em['subject'], em['body'])
        except Exception as e:
            logger.error(f'  F1 email error: {e}')

    advance_stage(conn, lead_id, 3, {
        'followup_count': (lead['followup_count'] or 0) + 1,
        'last_contacted': now_str(),
    })
    logger.info(f'  Stage →3 (F1) | WA draft 2 ready on dashboard')


def stage_followup2(conn, lead):
    """
    Stage 3 → 4
    48h after followup 1, still no reply.
    """
    lead_id = lead['id']
    hrs     = hours_since(lead['last_contacted'])

    if hrs < HOURS_FOLLOWUP2:
        logger.debug(
            f'  F2 not ready: {lead["business_name"][:30]} '
            f'({hrs:.0f}h / need {HOURS_FOLLOWUP2}h)'
        )
        return

    name = lead['business_name']
    logger.info(f'  Followup 2: {name[:35]} ({hrs:.0f}h since F1)')

    if lead.get('email') and lead.get('email_draft_3'):
        try:
            em = json.loads(lead['email_draft_3'])
            send_email(lead['email'], em['subject'], em['body'])
        except Exception as e:
            logger.error(f'  F2 email error: {e}')

    advance_stage(conn, lead_id, 4, {
        'followup_count': (lead['followup_count'] or 0) + 1,
        'last_contacted': now_str(),
    })
    logger.info(f'  Stage 3→4 (F2) | WA draft 3 ready on dashboard')


def stage_final(conn, lead):
    """
    Stage 4 → 5
    30 days since created, no response. Final message.
    Schedule deletion 5 days later.
    """
    lead_id = lead['id']
    dys     = days_since(lead['created_at'])

    if dys < DAYS_FINAL:
        logger.debug(
            f'  Final not ready: {lead["business_name"][:30]} '
            f'({dys:.0f}d / need {DAYS_FINAL}d)'
        )
        return

    name = lead['business_name']
    logger.info(f'  Final msg: {name[:35]} ({dys:.0f}d old)')

    if lead.get('email') and lead.get('email_draft_hot'):
        try:
            em = json.loads(lead['email_draft_hot'])
            send_email(
                lead['email'],
                f"Last message from {AGENCY_NAME}",
                em['body']
            )
        except Exception as e:
            logger.error(f'  Final email error: {e}')

    delete_at = (
        datetime.now() + timedelta(days=DAYS_DELETE)
    ).strftime('%Y-%m-%d %H:%M:%S')

    advance_stage(conn, lead_id, 5, {
        'lifecycle_status':    'DEAD',
        'scheduled_delete_at': delete_at,
        'last_contacted':      now_str(),
    })
    logger.info(
        f'  Stage 4→5 (FINAL) | '
        f'Delete scheduled: {delete_at}'
    )


def process_deletions(conn):
    now   = now_str()
    leads = conn.execute('''
        SELECT id, business_name FROM leads
        WHERE scheduled_delete_at IS NOT NULL
        AND scheduled_delete_at <= ?
        AND lifecycle_status = 'DEAD'
        AND (outreach_paused IS NULL OR outreach_paused = 0)
    ''', (now,)).fetchall()

    for l in leads:
        conn.execute('DELETE FROM leads WHERE id=?', (l['id'],))
        logger.info(f'  DELETED: {l["business_name"][:40]} (ID:{l["id"]})')

    if leads:
        conn.commit()
        logger.info(f'  Total deleted: {len(leads)}')


# ── MAIN CYCLE ────────────────────────────────────────────

def run_outreach_engine():
    logger.info('Outreach Engine — Starting cycle')

    try:
        with get_db() as conn:

            # Deletions first
            process_deletions(conn)

            # Load all active non-paused deployed leads
            leads = conn.execute('''
                SELECT * FROM leads
                WHERE status = 'Deployed'
                AND (outreach_paused IS NULL OR outreach_paused = 0)
                ORDER BY outreach_stage ASC, created_at ASC
            ''').fetchall()
            leads = [dict(l) for l in leads]

            logger.info(f'Active leads: {len(leads)}')

            for lead in leads:
                stage     = lead['outreach_stage'] or 0
                lifecycle = lead['lifecycle_status'] or 'NEW'
                name      = lead['business_name'][:35]

                try:
                    if stage == 0:
                        stage_0_initial(conn, lead)

                    elif stage == 1:
                        if (
                            lead['click_count']
                            and lead['click_count'] > 0
                            and lifecycle == 'HOT'
                        ):
                            fired = stage_hot_strike(conn, lead)
                            if not fired:
                                # HOT window passed — treat as normal followup
                                stage_followup1(conn, lead)
                        else:
                            stage_followup1(conn, lead)

                    elif stage == 2:
                        # After HOT strike — check for followup
                        stage_followup1(conn, lead)

                    elif stage == 3:
                        stage_followup2(conn, lead)

                    elif stage == 4:
                        stage_final(conn, lead)

                    # Stage 5 = DEAD, awaiting deletion — handled above

                except Exception as e:
                    logger.error(f'  Lead {name} error: {e}')
                    continue

        logger.info('Outreach Engine — Cycle complete')

    except Exception as e:
        logger.error(f'Engine error: {e}')


if __name__ == '__main__':
    print('\n' + '='*50)
    print('  Ghost Worker — Outreach Engine')
    print('='*50 + '\n')
    run_outreach_engine()
